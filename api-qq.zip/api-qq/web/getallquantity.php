<?php
include("../connection.php");
// http://139.59.251.210/api-qq/web/getallquantity.php
$stationID=$_GET[StationID];



$sql = "SELECT * from quantity_data";

$result = $conn->query($sql);

$tmpsend = array();
if ($result->num_rows > 0) 
{

    // output data of each row
    while($row = $result->fetch_assoc()) 
    {
    	array_push($tmpsend, array(	"station_id" => (int)$row["station_id"],
    						"ultrasonic" => (int)$row["ultrasonic"],
    						"time_receive" => (string)$row["time_receive"]));
    }
}

echo json_encode($tmpsend);


$conn->close();

?>
