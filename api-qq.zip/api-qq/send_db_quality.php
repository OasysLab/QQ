<?php
include("connection.php");
// 139.59.251.210/api-qq/send_db_quality.php?StationID=203&D_O=0&pH=0&Conductivity=0&temp=99
$StationID=$_GET[StationID];
$D_O=$_GET[D_O];
$pH=$_GET[pH];
$Conductivity=$_GET[Conductivity];
$temp = $_GET[temp];

date_default_timezone_set('Asia/Bangkok');
$now = date('Y-m-d H:i:s');

$sql = "INSERT INTO quality_data VALUES (	'$now',
											'$StationID',
											'$D_O',
											'$pH',
											'$Conductivity',
											'$temp'
										)";
// echo $sql;
$result = $conn->query($sql);

if ($result) 
{
   echo "Success";
}

$conn->close();

?>
